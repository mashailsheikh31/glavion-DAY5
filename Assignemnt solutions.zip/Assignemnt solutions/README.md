# Enterprise Attendance & Supervisor Portal v4.0

## Intern Profile
* **Intern Name:** Mashail Abdul Khaliq
* **Role:** Web Development Intern
* **Organization:** Glavion Solutions

## Project Overview
An enterprise-grade, multi-role web application featuring attendance tracking, leave applications, interactive supervisor approval workflows, client-side data analytics, and responsive dark mode support.

## Day-by-Day Architecture Breakdown

### Day 01 & Day 02: Core Foundations
* Real-time digital JavaScript clock & session state management.
* Mobile drawer navigation with backdrop overlays.
* Present, Late, and Absent attendance counters.

### Day 03: Feature Expansions
* **Search & Filter Engine:** Dynamic multi-condition filtering by date string and status dropdown.
* **Leave Module:** Dynamic leave balance decrementing and request tracking.
* **Client-Side CSV Export:** RFC-compliant CSV report generator via Blob API.
* **Dark Mode Theme:** Persistent CSS `:root` dynamic variables.

### Day 04: Capstone Integration
* **Supervisor / Admin Portal (`admin.html`):** Interactive Approve/Reject leave workflow updating `localStorage`.
* **Visual Analytics & Charts:** Custom SVG/CSS progress indicators and weekly trend bar charts.
* **Toast Notification Engine:** Animated feedback alerts for user actions.
* **Profile Modal HTML Fix:** Fully connected profile editor modal.

## Git Push Mandate
All code has been committed directly as raw source files without compressed `.zip` archives.