// Task 1: Initialize Supabase Client
window.SUPABASE_URL = window.SUPABASE_URL || 'https://rqxiyfjtdsfjzvbymsin.supabase.co'; 
window.SUPABASE_KEY = window.SUPABASE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJxeGl5Zmp0ZHNmanp2Ynltc2luIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk3NDU2MjAsImV4cCI6MjEwNTMyMTYyMH0.A6rnfJTGO5zF_MgdbYywXcVie00xHw4cQDSf0RzUU1c'; 
if (!window.supabaseClient) {
  window.supabaseClient = window.supabase ? window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_KEY) : null;
}
var supabase = window.supabaseClient;

// Toast Notification System
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast badge badge-${type === 'success' ? 'present' : type === 'danger' ? 'absent' : 'pending'}`;
  toast.style.cssText = `
    position: fixed; top: 1.25rem; right: 1.25rem; z-index: 9999;
    padding: 0.875rem 1.25rem; font-size: 0.9rem; border-radius: 6px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-weight: 600;
    transition: opacity 0.3s ease;
  `;
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// Initializer with Cloud Auth Protection
document.addEventListener('DOMContentLoaded', async () => {
  setupTheme();
  setupNavigation();
  
  const user = await checkAuthSession();
  
  // Page specific execution
  setupAuth();
  if (user) {
    setupClockAndAttendance(user);
    setupHistoryFilters(user);
    setupLeaveModule(user);
    setupProfileModule(user);
    setupAdminModule();
    setupRealtimeSync();
  }
});

async function checkAuthSession() {
  if (!supabase) {
    console.error("Supabase CDN correctly load nahi hua.");
    return null;
  }

  try {
    const { data: { user }, error } = await supabase.auth.getUser();
    const currentPage = window.location.pathname.split('/').pop();

    // Session missing warning ignore karein agar error 'Auth session missing!' ho
    if (error && error.message !== 'Auth session missing!') {
      console.warn("Auth Session Info:", error.message);
    }

    if (!user && currentPage !== 'index.html' && currentPage !== '') {
      window.location.href = 'index.html';
      return null;
    }
    
    if (user && (currentPage === 'index.html' || currentPage === '')) {
      window.location.href = 'dashboard.html';
    }

    return user;
  } catch (err) {
    console.error("Session verification failed:", err);
    return null;
  }
}

// Theme System
function setupTheme() {
  // 1. Saved theme load karke apply karein
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);

  const themeBtn = document.getElementById('theme-toggle-btn');
  if (themeBtn) {
    // Purane duplicate listeners remove karne ke liye clone
    const newBtn = themeBtn.cloneNode(true);
    themeBtn.parentNode.replaceChild(newBtn, themeBtn);

    newBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const current = document.documentElement.getAttribute('data-theme');
      const target = current === 'dark' ? 'light' : 'dark';
      
      document.documentElement.setAttribute('data-theme', target);
      localStorage.setItem('theme', target);
      
      if (typeof showToast === 'function') {
        showToast(`Switched to ${target} mode`, 'info');
      }
    });
  }
}

// Navigation System
function setupNavigation() {
  const toggleBtn = document.getElementById('mobile-toggle-btn');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');

  if (toggleBtn && sidebar && overlay) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('active');
      overlay.classList.toggle('active');
    });

    overlay.addEventListener('click', () => {
      sidebar.classList.remove('active');
      overlay.classList.remove('active');
    });
  }
}

// Task 2: Real Cloud Authentication (Login & Logout)
function setupAuth() {
  const loginForm = document.getElementById('login-form');
  const signupForm = document.getElementById('signup-form');
  const showSignupBtn = document.getElementById('show-signup-btn');
  const showLoginBtn = document.getElementById('show-login-btn');
  
  const authTitle = document.getElementById('auth-title');
  const authSubtitle = document.getElementById('auth-subtitle');
  const toggleToSignup = document.getElementById('toggle-to-signup');
  const toggleToLogin = document.getElementById('toggle-to-login');
  const errorMsg = document.getElementById('error-msg');

  // Switch to Sign Up View
  if (showSignupBtn) {
    showSignupBtn.addEventListener('click', (e) => {
      e.preventDefault();
      loginForm.style.display = 'none';
      signupForm.style.display = 'block';
      toggleToSignup.style.display = 'none';
      toggleToLogin.style.display = 'block';
      if (authTitle) authTitle.textContent = 'Create Account';
      if (authSubtitle) authSubtitle.textContent = 'Sign up to start tracking your attendance.';
      if (errorMsg) errorMsg.style.display = 'none';
    });
  }

  // Switch to Sign In View
  if (showLoginBtn) {
    showLoginBtn.addEventListener('click', (e) => {
      e.preventDefault();
      signupForm.style.display = 'none';
      loginForm.style.display = 'block';
      toggleToLogin.style.display = 'none';
      toggleToSignup.style.display = 'block';
      if (authTitle) authTitle.textContent = 'Welcome Back';
      if (authSubtitle) authSubtitle.textContent = 'Please enter your credentials to log in.';
      if (errorMsg) errorMsg.style.display = 'none';
    });
  }

  // Handle Sign In Submission
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;

      const { data, error } = await supabase.auth.signInWithPassword({ email, password });

      if (error) {
        if (errorMsg) {
          errorMsg.textContent = error.message;
          errorMsg.style.display = 'block';
        }
        showToast(error.message, 'danger');
      } else {
        showToast('Authenticated successfully!', 'success');
        setTimeout(() => window.location.href = 'dashboard.html', 500);
      }
    });
  }

  // Handle Sign Up Submission (Supabase Cloud Registration)
  if (signupForm) {
    signupForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fullName = document.getElementById('signup-name').value;
      const email = document.getElementById('signup-email').value;
      const password = document.getElementById('signup-password').value;

      const { data, error } = await supabase.auth.signUp({
        email: email,
        password: password,
        options: {
          data: {
            full_name: fullName
          }
        }
      });

      if (error) {
        if (errorMsg) {
          errorMsg.textContent = error.message;
          errorMsg.style.display = 'block';
        }
        showToast(error.message, 'danger');
      } else {
      
        signupForm.reset();
        
        // Success Message
        showToast('Account created successfully! Please sign in with your credentials.', 'success');
        
        await supabase.auth.signOut();

        // Automatically switch back to Sign In View
        signupForm.style.display = 'none';
        loginForm.style.display = 'block';
        toggleToLogin.style.display = 'none';
        toggleToSignup.style.display = 'block';
        if (authTitle) authTitle.textContent = 'Welcome Back';
        if (authSubtitle) authSubtitle.textContent = 'Please enter your credentials to log in.';
        if (errorMsg) errorMsg.style.display = 'none';

        // Email input mein auto-fill kar dein user ki convenience ke liye
        const loginEmailInput = document.getElementById('email');
        if (loginEmailInput) loginEmailInput.value = email;
      }
    });
  }
  // Handle Logout Button
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      await supabase.auth.signOut();
      showToast('Logged out successfully!', 'info');
      setTimeout(() => window.location.href = 'index.html', 500);
    });
  }
}

// Task 3: Cloud Clock & Attendance System
async function setupClockAndAttendance(user) {
  const clockEl = document.getElementById('clock-display');
  const dateEl = document.getElementById('current-date');
  
  if (clockEl) {
    setInterval(() => {
      const now = new Date();
      clockEl.textContent = now.toLocaleTimeString();
      if (dateEl) dateEl.textContent = now.toDateString();
    }, 1000);
  }

  const checkInBtn = document.getElementById('checkin-btn');
  const checkOutBtn = document.getElementById('checkout-btn');
  const todayStatus = document.getElementById('today-status');

  if (!checkInBtn || !checkOutBtn) return;

  const todayStr = new Date().toISOString().slice(0, 10);

  // Fetch today's record from Cloud Database
  const { data: records } = await supabase
    .from('attendance_records')
    .select('*')
    .eq('user_email', user.email)
    .eq('date', todayStr);

  let todayRecord = records && records.length > 0 ? records[0] : null;

  if (todayRecord) {
    checkInBtn.disabled = true;
    checkOutBtn.disabled = todayRecord.check_out !== '--';
    if (todayStatus) {
      todayStatus.className = `badge badge-${todayRecord.status.toLowerCase()}`;
      todayStatus.textContent = todayRecord.status;
    }
  } else {
    checkInBtn.disabled = false;
    checkOutBtn.disabled = true;
    if (todayStatus) {
      todayStatus.className = 'badge badge-pending';
      todayStatus.textContent = 'Not Checked In';
    }
  }

// Check-In Cloud Action (Updated with Duplicate Prevention)
checkInBtn.addEventListener('click', async () => {
  const now = new Date();
  const formattedDate = now.toISOString().slice(0, 10);
  const checkInTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // 1. Pehle Check Karein Ke Aaj Ka Record Pehle Se Exist To Nahi Karta
  const { data: existingRecords, error: fetchError } = await supabase
    .from('attendance_records')
    .select('*')
    .eq('user_email', user.email)
    .eq('date', formattedDate);

  if (fetchError) {
    showToast(fetchError.message, 'danger');
    return;
  }

  // Agar aaj ka record mil gaya to duplicate insert na karein
  if (existingRecords && existingRecords.length > 0) {
    showToast('Already Checked In!', 'warning');
    checkInBtn.disabled = true;
    checkOutBtn.disabled = existingRecords[0].check_out !== '--';
    return;
  }

  // 2. Agar Pehle Se Record NAHI Hai, Tab Hi Insert Karein
  const isLate = now.getHours() > 9 || (now.getHours() === 9 && now.getMinutes() > 30);
  const calculatedStatus = isLate ? 'Late' : 'Present';

  const { error } = await supabase
    .from('attendance_records')
    .insert([{
      user_email: user.email,
      date: formattedDate,
      check_in: checkInTime,
      check_out: '--',
      status: calculatedStatus
    }]);

  if (!error) {
    checkInBtn.disabled = true;
    checkOutBtn.disabled = false;
    if (todayStatus) {
      todayStatus.className = `badge badge-${calculatedStatus.toLowerCase()}`;
      todayStatus.textContent = calculatedStatus;
    }
    showToast(`Checked In at ${checkInTime} (${calculatedStatus})`, 'success');
    updateStats(user);
  } else {
    showToast(error.message, 'danger');
  }
});

// Check-Out Cloud Action
checkOutBtn.addEventListener('click', async () => {
  const now = new Date();
  const formattedDate = now.toISOString().slice(0, 10);
  const checkOutTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const { error } = await supabase
    .from('attendance_records')
    .update({ check_out: checkOutTime })
    .eq('user_email', user.email)
    .eq('date', formattedDate);

  if (!error) {
    checkOutBtn.disabled = true;
    showToast(`Checked Out at ${checkOutTime}`, 'success');
    updateStats(user);
  } else {
    showToast(error.message, 'danger');
  }
});

updateStats(user);
}

// Fetch Stats from Cloud
async function updateStats(user) {
const historyTableBody = document.getElementById('history-table-body');
  if (!historyTableBody) return;

  // Supabase se records fetch karein (Latest first)
  const { data: records, error } = await supabase
    .from('attendance_records')
    .select('*')
    .eq('user_email', user.email)
    .order('date', { ascending: false });

  if (error) {
    showToast('Failed to load history', 'danger');
    return;
  }

  // Duplicate dates handle karne ke liye Map Map Object
  const uniqueRecordsMap = new Map();

  records.forEach(record => {
    // Agar date pehle se map mein nahi hai, ya current record mein check_out information updated hai
    if (!uniqueRecordsMap.has(record.date)) {
      uniqueRecordsMap.set(record.date, record);
    } else {
      // Agar existing record mein check_out missing hai aur naye record mein majood hai, to update karein
      const existing = uniqueRecordsMap.get(record.date);
      if (existing.check_out === '--' && record.check_out !== '--') {
        uniqueRecordsMap.set(record.date, record);
      }
    }
  });

  const uniqueRecords = Array.from(uniqueRecordsMap.values());

  // Table render logic
  historyTableBody.innerHTML = '';
  if (uniqueRecords.length === 0) {
    historyTableBody.innerHTML = `<tr><td colspan="4" style="text-align:center;">No attendance records found.</td></tr>`;
    return;
  }

  uniqueRecords.forEach(rec => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${rec.date}</td>
      <td>${rec.check_in || '--'}</td>
      <td>${rec.check_out || '--'}</td>
      <td><span class="badge badge-${(rec.status || 'present').toLowerCase()}">${rec.status}</span></td>
    `;
    historyTableBody.appendChild(row);
  });
}

// Task 3: Cloud History Fetch & Export
async function setupHistoryFilters(user) {
  const tableBody = document.getElementById('history-table-body');
  const searchInput = document.getElementById('search-input');
  const statusFilter = document.getElementById('status-filter');
  const exportBtn = document.getElementById('export-csv-btn');

  if (!tableBody) return;

  const { data: attendanceHistory } = await supabase
    .from('attendance_records')
    .select('*')
    .eq('user_email', user.email)
    .order('id', { ascending: false });

  const history = attendanceHistory || [];

  function renderTable(data) {
    tableBody.innerHTML = data.map(record => `
      <tr>
        <td>${record.date}</td>
        <td>${record.check_in}</td>
        <td>${record.check_out}</td>
        <td><span class="badge badge-${record.status.toLowerCase()}">${record.status}</span></td>
      </tr>
    `).join('');
  }

  function filterData() {
    const query = searchInput ? searchInput.value.toLowerCase() : '';
    const status = statusFilter ? statusFilter.value : 'All';

    const filtered = history.filter(record => {
      const matchesSearch = record.date.toLowerCase().includes(query);
      const matchesStatus = status === 'All' || record.status === status;
      return matchesSearch && matchesStatus;
    });

    renderTable(filtered);
  }

  if (searchInput) searchInput.addEventListener('input', filterData);
  if (statusFilter) statusFilter.addEventListener('change', filterData);

  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      let csv = 'Date,Check In,Check Out,Status\n';
      history.forEach(r => {
        csv += `${r.date},${r.check_in},${r.check_out},${r.status}\n`;
      });
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `attendance_history_${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      showToast('CSV report generated & downloaded!', 'info');
    });
  }

  renderTable(history);
}

// Task 4: Cloud Leave Management
async function setupLeaveModule(user) {
  const leaveForm = document.getElementById('leave-form');
  const leaveTable = document.getElementById('leave-table-body');

  async function renderLeaveDashboard() {
    const { data: requests, error } = await supabase
      .from('leave_requests')
      .select('*')
      .eq('user_email', user.email)
      .order('id', { ascending: false });

    if (error) {
      console.error("Fetch leaves error:", error.message);
      return;
    }

    const leaveRequests = requests || [];

    const takenCount = document.getElementById('taken-count') || document.getElementById('total-leaves');
    if (takenCount) takenCount.textContent = leaveRequests.length;

    if (leaveTable) {
      if (leaveRequests.length === 0) {
        leaveTable.innerHTML = `<tr><td colspan="4" style="text-align:center;">No leave applications submitted yet.</td></tr>`;
        return;
      }

      leaveTable.innerHTML = leaveRequests.map(req => {
        let badgeClass = 'badge-pending';
        if (req.status === 'Approved') badgeClass = 'badge-present';
        if (req.status === 'Rejected') badgeClass = 'badge-absent';

        return `
          <tr>
            <td>${req.leave_type}</td>
            <td>${req.start_date} to ${req.end_date}</td>
            <td>${req.reason}</td>
            <td><span class="badge ${badgeClass}">${req.status}</span></td>
          </tr>
        `;
      }).join('');
    }
  }

  if (leaveForm) {
    // 1. Purane Duplicate Event Listeners Clean Karein
    const newForm = leaveForm.cloneNode(true);
    leaveForm.parentNode.replaceChild(newForm, leaveForm);

    newForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const submitBtn = newForm.querySelector('button[type="submit"]');
      if (submitBtn) submitBtn.disabled = true; // Double click prevent karne ke liye

      const type = document.getElementById('leave-type').value;
      const startDate = document.getElementById('leave-start').value;
      const endDate = document.getElementById('leave-end').value;
      const reason = document.getElementById('leave-reason').value.trim();

      if (new Date(startDate) > new Date(endDate)) {
        showToast('End Date cannot be earlier than Start Date!', 'warning');
        if (submitBtn) submitBtn.disabled = false;
        return;
      }

      const internName = user.user_metadata?.full_name || user.email.split('@')[0];

      const { error } = await supabase
        .from('leave_requests')
        .insert([{
          intern_name: internName,
          user_email: user.email,
          leave_type: type,
          start_date: startDate,
          end_date: endDate,
          reason: reason,
          status: 'Pending'
        }]);

      if (!error) {
        await renderLeaveDashboard();
        newForm.reset();
        showToast('Leave application submitted successfully!', 'success');
      } else {
        showToast(error.message, 'danger');
      }

      if (submitBtn) submitBtn.disabled = false; // Re-enable button
    });
  }
  

  renderLeaveDashboard();
}
// Profile Display Module
function setupProfileModule(user) {
  const nameDisp = document.getElementById('profile-name-display');
  const roleDisp = document.getElementById('profile-role-display');
  const emailDisp = document.getElementById('profile-email-display');
  const avatarDisp = document.getElementById('avatar-display');

  const username = user.email.split('@')[0];
  const formattedName = username.charAt(0).toUpperCase() + username.slice(1);

  if (nameDisp) nameDisp.textContent = user.user_metadata?.full_name || formattedName;
  if (roleDisp) roleDisp.textContent = 'Web Development Intern';
  if (emailDisp) emailDisp.textContent = user.email;
  if (avatarDisp) avatarDisp.textContent = formattedName.slice(0, 2).toUpperCase();
}

// Task 4: Admin Cloud Approval Workflow
async function setupAdminModule() {
  const tableBody = document.getElementById('admin-leave-table-body');
  if (!tableBody) return;

  const { data: requests, error } = await supabase
    .from('leave_requests')
    .select('*')
    .order('id', { ascending: false });

  if (error) {
    console.error('Error fetching requests:', error.message);
    return;
  }

  tableBody.innerHTML = '';

  if (requests.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="6" class="text-center">No leave requests found.</td></tr>`;
    return;
  }

  requests.forEach((req) => {
    const row = document.createElement('tr');
    row.setAttribute('data-request-id', req.id); // Dynamic ID attribute for instant DOM targeting

    let badgeClass = 'bg-warning';
    if (req.status === 'Approved') badgeClass = 'bg-success';
    if (req.status === 'Rejected') badgeClass = 'bg-danger';

    const actionButtons = req.status === 'Pending' ? `
      <button class="btn btn-sm btn-success me-1" onclick="updateStatus('${req.id}', 'Approved')">Approve</button>
      <button class="btn btn-sm btn-danger" onclick="updateStatus('${req.id}', 'Rejected')">Reject</button>
    ` : `<span class="badge bg-secondary">Processed</span>`;

    row.innerHTML = `
      <td>${req.intern_name || 'N/A'}</td>
      <td>${req.leave_type}</td>
      <td>${req.start_date} to ${req.end_date}</td>
      <td>${req.reason || '-'}</td>
      <td class="status-cell"><span class="badge ${badgeClass}">${req.status}</span></td>
      <td class="action-cell">${actionButtons}</td>
    `;

    tableBody.appendChild(row);
  });
}

// Approve / Reject Handler Function
async function updateStatus(requestId, newStatus) {
  try {
    // 1. Supabase mein Status update update karein
    const { data, error } = await supabase
      .from('leave_requests')
      .update({ status: newStatus })
      .eq('id', requestId)
      .select();

    if (error) {
      console.error('Update Error:', error.message);
      showToast(`Error updating status: ${error.message}`, 'danger');
      return;
    }

    showToast(`Leave request ${newStatus.toLowerCase()} successfully!`, 'success');

    // 2. DOM Row Status Instant Update (Without full reload wait)
    const rowElement = document.querySelector(`[data-request-id="${requestId}"]`);
    if (rowElement) {
      const statusCell = rowElement.querySelector('.status-cell');
      const actionCell = rowElement.querySelector('.action-cell');

      if (statusCell) {
        let badgeClass = newStatus === 'Approved' ? 'bg-success' : 'bg-danger';
        statusCell.innerHTML = `<span class="badge ${badgeClass}">${newStatus}</span>`;
      }

      if (actionCell) {
        actionCell.innerHTML = `<span class="badge bg-secondary">Processed</span>`;
      }
    }

    // 3. Admin Table Data Re-fetch karein
    if (typeof renderAdminRequests === 'function') {
      await renderAdminRequests();
    }
  } catch (err) {
    console.error('Unexpected error:', err);
  }
}

// Task 5: Realtime WebSocket Synchronization
function setupRealtimeSync() {
  supabase
    .channel('live-leave-updates')
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'leave_requests' }, (payload) => {
      showToast(`Your leave status was updated to: ${payload.new.status}`, payload.new.status === 'Approved' ? 'success' : 'danger');
      const leaveTable = document.getElementById('leave-table-body');
      if (leaveTable) {
        location.reload(); // Re-render application upon update
      }
    })
    .subscribe();
}